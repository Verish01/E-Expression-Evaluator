/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "evaluator.h"

Evaluator::Evaluator(){
    symtable = new SymbolTable(); // Initialize the symbol table
}

Evaluator::~Evaluator() {
    delete symtable;
    for (auto tree : expr_trees) {
        delete tree;
    }
    expr_trees.clear();
}

void Evaluator::parse(vector<string> code) {
    // Implement code parsing and tree construction here
    for (const string& expression : code) {
        ExprTreeNode* root = parseExpression(expression);
        if (root != nullptr) {
            expr_trees.push_back(root);
        }
    }
}

void Evaluator::eval() {
    // Evaluate the last element of the expr_trees (assuming it's the most recent one)
    if (!expr_trees.empty()) {
        ExprTreeNode* root = expr_trees.back();
        UnlimitedRational* result = evaluateTree(root);
        symtable->insert("result", result);
    }
}

UnlimitedRational* evaluateTree(ExprTreeNode* node) {
    SymbolTable* symtable = new SymbolTable();
    if (node == nullptr) {
        return nullptr; // Handle null nodes
    }
    if (node->type == "VAL") {
        return node->val;
    } else if (node->type == "VAR") {
        return symtable->search(node->id);
    } else if (node->type == "ADD") {
        // Evaluate left and right subtrees, then perform addition
        UnlimitedRational* leftVal = evaluateTree(node->left);
        UnlimitedRational* rightVal = evaluateTree(node->right);
        if (leftVal != nullptr && rightVal != nullptr) {
            return UnlimitedRational::add(leftVal, rightVal);
        } else {
            return nullptr;
        }
    } else if (node->type == "SUB") {
        // Evaluate left and right subtrees, then perform subtraction
        UnlimitedRational* leftVal = evaluateTree(node->left);
        UnlimitedRational* rightVal = evaluateTree(node->right);
        if (leftVal != nullptr && rightVal != nullptr) {
            return UnlimitedRational::sub(leftVal, rightVal);
        } else {
            // Handle errors or invalid operands
            return nullptr;
        }
    } else if (node->type == "MUL") {
        // Evaluate left and right subtrees, then perform multiplication
        UnlimitedRational* leftVal = evaluateTree(node->left);
        UnlimitedRational* rightVal = evaluateTree(node->right);
        if (leftVal != nullptr && rightVal != nullptr) {
            return UnlimitedRational::mul(leftVal, rightVal);
        } else {
            return nullptr;
        }
    } else if (node->type == "DIV") {
        // Evaluate left and right subtrees, then perform division
        UnlimitedRational* leftVal = evaluateTree(node->left);
        UnlimitedRational* rightVal = evaluateTree(node->right);
        if (leftVal != nullptr && rightVal != nullptr) {
            if (!rightVal==0) {
                return UnlimitedRational::div(leftVal, rightVal);
            } else {
                // Handle division by zero error
                return nullptr;
            }
        } else {
            // Handle errors or invalid operands
            return nullptr;
        }
    } else {
        // Handle unknown or unsupported operation type
        return nullptr;
    }
};

ExprTreeNode* createParseTree(const string& expression) {
    vector<string> tokens = tokenizeExpression(expression);
    int rootIndex = findRootOperator(tokens);

    if (rootIndex == -1) {
        return nullptr;
    }

    string rootOperator = tokens[rootIndex];
    ExprTreeNode* rootNode = new ExprTreeNode(rootOperator, nullptr);

    string leftExpression = joinTokens(tokens, 0, rootIndex);
    string rightExpression = joinTokens(tokens, rootIndex + 1, tokens.size());

    rootNode->left = createParseTree(leftExpression);
    rootNode->right = createParseTree(rightExpression);

    return rootNode;
}

vector<string> tokenizeExpression(const string& expression) {
    vector<string> tokens;
    istringstream iss(expression);
    string token;
    while (iss >> token) {
        tokens.push_back(token);
    }
    return tokens;
}

int findRootOperator(const vector<string>& tokens) {
    int lowestPrecedence = 1e-12;
    int rootIndex = -1;
    int parenthesesCount = 0;

    for (int i = 0; i < tokens.size(); ++i) {
        string token = tokens[i];

        if (token == "(") {
            ++parenthesesCount;
        } else if (token == ")") {
            --parenthesesCount;
        }

        if (parenthesesCount == 0) {
            int precedence = getOperatorPrecedence(token);

            if (precedence != -1 && precedence <= lowestPrecedence) {
                lowestPrecedence = precedence;
                rootIndex = i;
            }
        }
    }

    return rootIndex;
}

int getOperatorPrecedence(const string& op) {
    if (op == "+" || op == "-") {
        return 1;
    } else if (op == "*" || op == "/") {
        return 2;
    }
    return -1; // Invalid operator
}

string joinTokens(const vector<string>& tokens, int start, int end) {
    string result;
    for (int i = start; i < end; ++i) {
        result += tokens[i] + " ";
    }
    return result;
}
ExprTreeNode* parseExpression(const string& expression) {
    ExprTreeNode* root = createParseTree(expression);
    return root;
    return nullptr;
}

bool isOperator(const string& token) {
    return (token == "+" || token == "-" || token == "*" || token == "/");
}

bool isVariable(const string& token) {
    return (token.size() == 1 && isalpha(token[0]));
}
/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "ulimitedrational.h"
#include "ulimitedint.h"
#include <string>
using namespace std;

    UnlimitedRational::UnlimitedRational(){
        p=(new UnlimitedInt());
        q=(new UnlimitedInt(1));
    }

UnlimitedRational::UnlimitedRational(UnlimitedInt* num, UnlimitedInt* den) : p(num), q(den) {
    simplify();
}

// Destructor
UnlimitedRational::~UnlimitedRational() {
    delete p;
    delete q;
}

// Getter methods
UnlimitedInt* UnlimitedRational::get_p() {
    return p;
}

UnlimitedInt* UnlimitedRational::get_q() {
    return q;
}

string UnlimitedRational::get_p_str() {
    return p->to_string();
}

string UnlimitedRational::get_q_str() {
    return q->to_string();
}

string UnlimitedRational::get_frac_str() {
    return p->to_string() + "/" + q->to_string();
}

// Static methods for arithmetic operations
UnlimitedRational* UnlimitedRational::add(UnlimitedRational* i1, UnlimitedRational* i2) {
    UnlimitedInt* num1 = i1->get_p();
    UnlimitedInt* den1 = i1->get_q();
    UnlimitedInt* num2 = i2->get_p();
    UnlimitedInt* den2 = i2->get_q();

    // Calculate the result numerator and denominator
    UnlimitedInt* result_num = UnlimitedInt::add(UnlimitedInt::mul(num1, den2), UnlimitedInt::mul(num2, den1));
    UnlimitedInt* result_den = UnlimitedInt::mul(den1, den2);

    return new UnlimitedRational(result_num, result_den);
}

UnlimitedRational* UnlimitedRational::sub(UnlimitedRational* i1, UnlimitedRational* i2) {
    UnlimitedInt* num1 = i1->get_p();
    UnlimitedInt* den1 = i1->get_q();
    UnlimitedInt* num2 = i2->get_p();
    UnlimitedInt* den2 = i2->get_q();

    // Calculate the result numerator and denominator
    UnlimitedInt* result_num = UnlimitedInt::sub(UnlimitedInt::mul(num1, den2), UnlimitedInt::mul(num2, den1));
    UnlimitedInt* result_den = UnlimitedInt::mul(den1, den2);

    return new UnlimitedRational(result_num, result_den);
}

UnlimitedRational* UnlimitedRational::mul(UnlimitedRational* i1, UnlimitedRational* i2) {
    UnlimitedInt* num1 = i1->get_p();
    UnlimitedInt* den1 = i1->get_q();
    UnlimitedInt* num2 = i2->get_p();
    UnlimitedInt* den2 = i2->get_q();

    // Calculate the result numerator and denominator
    UnlimitedInt* result_num = UnlimitedInt::mul(num1, num2);
    UnlimitedInt* result_den = UnlimitedInt::mul(den1, den2);

    return new UnlimitedRational(result_num, result_den);
}

UnlimitedRational* UnlimitedRational::div(UnlimitedRational* i1, UnlimitedRational* i2) {
    UnlimitedInt* num1 = i1->get_p();
    UnlimitedInt* den1 = i1->get_q();
    UnlimitedInt* num2 = i2->get_p();
    UnlimitedInt* den2 = i2->get_q();

    // Calculate the result numerator and denominator
    UnlimitedInt* result_num = UnlimitedInt::mul(num1, den2);
    UnlimitedInt* result_den = UnlimitedInt::mul(den1, num2);

    return new UnlimitedRational(result_num, result_den);
}

// Helper method to simplify the fraction
void simplify() {
    UnlimitedInt* common = gcd(p, q);
    if (!common==1) {
        p->divBy(common);
        q->divBy(common);
    }
    delete common;

    if (q->isNegative()) {
        p->negate();
        q->negate();
    }
}

// Helper method to calculate the greatest common divisor
UnlimitedInt* gcd(UnlimitedInt* a, UnlimitedInt* b) {
    while (b!=0) {
        UnlimitedInt* temp = b;
        b = UnlimitedInt::mod(a, b);
        a = temp;
        delete temp;
    }
    return a;
}
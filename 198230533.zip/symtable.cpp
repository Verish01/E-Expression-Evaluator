/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include "symtable.h"
SymbolTable::SymbolTable(){
    size=(0);
    root=(nullptr);
}

SymbolTable::~SymbolTable() {
    deleteTree(root);
}

void SymbolTable::insert(string k, UnlimitedRational* v) {
    root = insertRec(root, k, v);
}

SymEntry* insertRec(SymEntry* node, string k, UnlimitedRational* v) {
    int size=0;
    if (node == nullptr) {
        size++;
        return new SymEntry(k, v);
    }

    if (k < node->key) {
        node->left = insertRec(node->left, k, v);
    } else if (k > node->key) {
        node->right = insertRec(node->right, k, v);
    } else {
        // Duplicate keys are not allowed (you can handle this case accordingly)
    }

    return node;
}

void SymbolTable::remove(string k) {
    root = deleteRec(root, k);
}

SymEntry* deleteRec(SymEntry* node, string k) {
    int size=0;
    if (node == nullptr) {
        return node;
    }

    if (k < node->key) {
        node->left = deleteRec(node->left, k);
    } else if (k > node->key) {
        node->right = deleteRec(node->right, k);
    } else {
        if (node->left == nullptr) {
            SymEntry* temp = node->right;
            delete node->val;
            delete node;
            size--;
            return temp;
        } else if (node->right == nullptr) {
            SymEntry* temp = node->left;
            delete node->val;
            delete node;
            size--;
            return temp;
        }

        SymEntry* temp = findMin(node->right);
        node->key = temp->key;
        node->val = temp->val;
        node->right = deleteRec(node->right, temp->key);
    }

    return node;
}

UnlimitedRational* SymbolTable::search(string k) {
    SymEntry* entry = searchRec(root, k);
    if (entry != nullptr) {
        return entry->val;
    } else {
        return nullptr;
    }
}

SymEntry* searchRec(SymEntry* node, string k) {
    if (node == nullptr || node->key == k) {
        return node;
    }

    if (k < node->key) {
        return searchRec(node->left, k);
    }

    return searchRec(node->right, k);
}

int SymbolTable::get_size() {
    return size;
}

SymEntry* SymbolTable::get_root() {
    return root;
}

SymEntry* findMin(SymEntry* node) {
    while (node->left != nullptr) {
        node = node->left;
    }
    return node;
}

void deleteTree(SymEntry* node) {
    if (node == nullptr) {
        return;
    }

    deleteTree(node->left);
    deleteTree(node->right);

    delete node->val;
    delete node;
}
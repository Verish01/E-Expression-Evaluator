/* Do NOT add/remove any includes statements from this header file */
/* unless EXPLICTLY clarified on Piazza. */
#include<bits/stdc++.h>
#include "ulimitedint.h"
#include <string>
using namespace std;

UnlimitedInt::UnlimitedInt(){
    size=1;
    sign=1;
    capacity=4;
    unlimited_int=new int[capacity];
    unlimited_int[0]=0;
};

UnlimitedInt::UnlimitedInt(string s){
    size = 0;
    sign = 1;
    capacity = 4;
    unlimited_int = new int[capacity];
    unlimited_int[0] = 0;
    if (s.empty()){
        return;
    }
    if (s[0]=='-'){
        sign=-1;
        s=s.substr(1);
    }

    for (int i=0; i<s.length(); i++){
        if (isdigit(s[i])){
            int num=s[i]-'0';
            if (size==capacity){
                capacity*=2;
                int* newArray= new int[capacity];
                for (int j=0; j<size; j++){
                    newArray[j]=unlimited_int[j];
                }
                delete[] unlimited_int;
                unlimited_int=newArray;
                capacity=capacity*2;
            }
            unlimited_int[size++]=num;
        }
    }
}; // Create from string 

UnlimitedInt::UnlimitedInt(int i){
    size=0;
    capacity=4;
    unlimited_int=new int[capacity];
    if (i<0){
        sign=-1;
        i=-i;
    }
    else{
        sign=1;
    }
    if (i==0){
        size=1;
        unlimited_int[0]=0;
    }

    while(i>0){
        int num=i%10;
        i/=10;
        if (size==capacity){;
            int* newArray=new int[2*capacity];
            for (int j=0; j<size; j++){
                newArray[j]= unlimited_int[j];
            }
            delete[] unlimited_int;
            capacity=capacity*2;
            unlimited_int = newArray;
        }
        for (int k=size-1; k>=0; k--){
            unlimited_int[k+1]=unlimited_int[k];
        }
        unlimited_int[0]=num;
        size++;
    }
}; // Create from int
UnlimitedInt::UnlimitedInt(int* ulimited_int, int cap, int sgn, int sz){
    size=sz;
    sign=sgn;
    capacity=cap;
    unlimited_int=ulimited_int;
}; // Complete constructor

UnlimitedInt::~UnlimitedInt(){
    delete[] unlimited_int;
};

// Return the size of the unlimited int
int UnlimitedInt::get_size(){
    return size;
};

// Return the unlimited_int array
int* UnlimitedInt::get_array(){
    return unlimited_int;
};

// Get sign
int UnlimitedInt::get_sign(){
    return sign;
};

// Get capacity 
int UnlimitedInt::get_capacity(){
    return capacity;
};

// Implement these integer operations as they are defined for integers in mathematics
// (Since there are no size restrictions)
void reverseArray(int arr[], int size) {
    int start = 0;
    int end = size - 1;

    while (start < end) {
        // Swap the elements at start and end positions
        int temp = arr[start];
        arr[start] = arr[end];
        arr[end] = temp;

        // Move the pointers towards the center
        start++;
        end--;
    }
}
int removeLeadingZeroes(int arr[], int size) {
    int nonZeroIndex = 0;

    // Find the first non-zero element

    while (nonZeroIndex < size && arr[nonZeroIndex] == 0) {
        // cout<<nonZeroIndex<<"mai hun don"<<endl;
        nonZeroIndex++;
    }
    if (nonZeroIndex == size) {
        // All elements are zero, set size to 1
        size = 1;
    } else {
        // Shift non-zero elements to the beginning
        for (int i = 0; i < size - nonZeroIndex; i++) {
            arr[i] = arr[nonZeroIndex + i];
        }
        size -= nonZeroIndex;
    }
    return size;
}
int compare(int num1[], int size1, int num2[], int size2) {
    // Compare the sizes first
    if (size1 < size2) return -1;
    if (size1 > size2) return 1;

    // If sizes are equal, compare element by element
    for (int i =0; i <size1; i++) {
        if (num1[i] < num2[i]) return -1;
        if (num1[i] > num2[i]) return 1;
    }

    return 0; // Both arrays are equal
}
UnlimitedInt* UnlimitedInt::add(UnlimitedInt* i1, UnlimitedInt* i2){
    UnlimitedInt* result=new UnlimitedInt();
    
    int carry=0;
    int sign1=i1->get_sign();
    int sign2=i2->get_sign();
    if ((sign1==1) && (sign2==-1)){
        i2->sign=1;
        result=sub(i1,i2);
        i2->sign=-1;
        return result;
    }
    else if ((sign1==-1) && (sign2==1)){
        i1->sign=1;
        result=sub(i1,i2);
        i1->sign=-1;
        return result;
    }

    int size1=i1->get_size();
    int size2=i2->get_size();
    int max_size=max(size1, size2);
    result->capacity=max_size+1;
    int j=0;
    int ind1 = 0;
    int ind2 = 0;
    result->size = max_size+1;
    for(int i = 0;i<max_size+1;i++){
        result->get_array()[i] = 0;
    }
    reverseArray(i1->get_array(),size1);
    reverseArray(i2->get_array(),size2);
    while(ind1<size1 and ind2<size2){
        int d1=0;
        d1=i1->get_array()[ind1];
        int d2=0;
        d2=i2->get_array()[ind2];
            // cout<<d2<<endl;
        int sum = d1 + d2 + carry;
        // cout<<sum<<endl;
        carry = sum / 10;
        result->get_array()[j]= sum % 10;
        j++;
        ind1++;
        ind2++;
    }
    while(ind1<size1){
        int d1=0;
        d1=i1->get_array()[ind1];
            // cout<<d2<<endl;
        int sum = d1 + carry;
        carry = sum / 10;
        result->get_array()[j]= sum % 10;
        j++;
        ind1++;
    }
    while(ind2<size2){
        int d2=0;
        d2=i2->get_array()[ind2];
            // cout<<d2<<endl;
        int sum = d2 + carry;
        carry = sum / 10;
        result->get_array()[j]= sum % 10;
        j++;
        ind2++;
    }
    
// If there's a carry after the loop, set the most significant digit
    if (carry > 0) {
        result->get_array()[j] = carry;
        j++;
    }
    // int n=sizeof(result)/sizeof(result);
    reverseArray(result->get_array(),max_size+1);
    result->size = removeLeadingZeroes(result->get_array(),result->size);
    result->sign=i1->sign;
    return result;
};

UnlimitedInt* UnlimitedInt::sub(UnlimitedInt* i1, UnlimitedInt* i2){
    UnlimitedInt* result=new UnlimitedInt();
    int borrow=0;
    int sign1=i1->get_sign();
    int sign2=i2->get_sign();
    if (sign1==-1 && sign2==1){
        i1->sign=1;
        result=add(i1,i2);
        i1->sign=-1;
        result->sign=-1;
        return result;
    }
    if(sign1==1 && sign2==-1){
        i2->sign=1;
        result=add(i1,i2);
        i2->sign=-1;
        result->sign=1;
        return result;
    }

    int size1=i1->get_size();
    int size2=i2->get_size();
    int max_size=max(size1,size2);
    result->capacity=max_size+1;
    result->size = max_size+1;
    int j=0;
    int ind1 = 0;
    int ind2 = 0;
    reverseArray(i1->get_array(),size1);
    reverseArray(i2->get_array(),size2);
    while(ind1<size1 and ind2<size2){
        int d1=0;
        d1=i1->get_array()[ind1];
        int d2=0;
        d2=i2->get_array()[ind2];
        int diff=d1-d2-borrow;
        if (diff < 0) {
            borrow = 1;
            diff += 10;
        } else {
            borrow = 0;
        }
        result->get_array()[j]=diff;
        j++;
        ind1++;
        ind2++;
    }
    while(ind1<size1){
        int d1=0;
        d1=i1->get_array()[ind1];
            // cout<<d2<<endl;
        int diff = d1 -borrow;
        if (diff < 0) {
            borrow = 1;
            diff += 10;
        } else {
            borrow = 0;
        }
        result->get_array()[j]=diff;
        j++;
        ind1++;
    }
    while(ind2<size2){
        int d2=0;
        d2=i2->get_array()[ind2];
            // cout<<d2<<endl;
        int diff = d2 - borrow;
        if (diff < 0) {
            borrow = 1;
            diff += 10;
        } else {
            borrow = 0;
        }
        result->get_array()[j]= diff;
        j++;
        ind2++;
    }
    reverseArray(result->get_array(),j);
    removeLeadingZeroes(result->get_array(),result->size);
    if (size1>size2){
        result->sign=i1->sign;
    }
    else if(size1<size2){
        result->sign=i2->sign;
    }
    else{
        for (int i = 0; i <size1; i++) {
            if (i1->get_array()[i] > i2->get_array()[i]) {
                result->sign=i1->sign; // i1 is greater
            } else if (i1->get_array()[i] < i2->get_array()[i]) {
                result->sign=i2->sign; // i2 is greater
            }
        }
    }
    return result;
};

UnlimitedInt* UnlimitedInt::mul(UnlimitedInt* i1, UnlimitedInt* i2){
    UnlimitedInt* result=new UnlimitedInt();
    if ((i1->sign==-1 && i2->sign==1) || (i1->sign==1 && i2->sign==-1)){
        result->sign=-1;
    }
    else{
        result->sign=1;
    }
    int size1=i1->get_size();
    int size2=i2->get_size();
    // int max_size=max(size1,size2);

    int cap=size1+size2;
    result->capacity=size1+size2;
    result->size = size1+size2;
    for (int i=0; i<cap; i++){
        result->get_array()[i]=0;
    }
    // result->size=0;
    if (size1<=size2){
        for (int i = size1-1; i>=0 ; i--) {
            int carry = 0;
            cout<<"hi1"<<endl;
            for (int j = size2-1; j >=0; j--) {
                int product = i1->get_array()[i] * i2->get_array()[j] + result->get_array()[i + j+1] + carry;
                // cout<<product<<endl;
                carry = product / 10;
                result->get_array()[i + j+1] = product % 10;
                // cout << result[i+j] <<endl;
            }
            result->get_array()[i] += carry;
        }
    }
    else{
        for (int i = size2-1; i>=0 ; i--) {
            int carry = 0;
            for (int j = size1-1; j >=0; j--) {
                int product = i2->get_array()[i] * i1->get_array()[j] + result->get_array()[i + j+1] + carry;
                carry = product / 10;
                result->get_array()[i+j+1] = product % 10;
            }
            result->get_array()[i] += carry;
        }
    }

    removeLeadingZeroes(result->get_array(),result->get_size());
    return result;
};

UnlimitedInt* UnlimitedInt::div(UnlimitedInt* i1, UnlimitedInt* i2){
    UnlimitedInt* result=new UnlimitedInt();
    if ((i1->sign==-1 && i2->sign==1) || (i1->sign==1 && i2->sign==-1)){
        result->sign=-1;
    }
    else{
        result->sign=1;
    }
    
    int size1=i1->get_size();
    int size2=i2->get_size();
    int max_size=max(size1,size2);
    UnlimitedInt* arr1=new UnlimitedInt();
    arr1->capacity=max_size;
    arr1->size = max_size;
    for (int i=0; i<max_size; i++){
        arr1[i]=0;
    }
    UnlimitedInt* arr2=new UnlimitedInt();
    arr2->capacity=max_size;
    arr2->size = max_size;
    for (int j=0; j<max_size-1; j++){
        arr2[j]=0;
    }
    arr2[max_size-1]=1;
    UnlimitedInt *a = new UnlimitedInt();
    a = i2;
    // cout<<size1<<size2<<"pagal"<<endl;
    if (size1>=size2){
        bool found = false;
        while(not found){
            // cout<<(compare(i1->get_array(),i1->get_size(),a->get_array(),a->get_size()))<<"pagal"<<endl;
            if ((compare(i1->get_array(),i1->get_size(),i2->get_array(),i2->get_size()))==1) {
                // cout<<(compare(i1->get_array(),i1->get_size(),a->get_array(),a->get_size()))<<"pagal"<<endl;
                i2=add(i2,a);
                // cout<<i2->get_size()<<"pagal"<<i2->get_array()[0]<<"hi2"<<endl;
                arr1 = add(arr1,arr2);
            }
            else{
                found = true;
            }
            
        }
        arr1->size = removeLeadingZeroes(arr1->get_array(),arr1->size);
        return arr1;
    }
    else{
        arr1->size = removeLeadingZeroes(arr1->get_array(),arr1->size);
        return arr1;
    }
};

UnlimitedInt* UnlimitedInt::mod(UnlimitedInt* i1, UnlimitedInt* i2){
    UnlimitedInt* result=new UnlimitedInt();
    if ((i1->sign==-1 && i2->sign==1) || (i1->sign==1 && i2->sign==-1)){
        result->sign=-1;
    }
    else{
        result->sign=1;
    }
    int size1=i1->get_size();
    int size2=i2->get_size();
    int max_size=max(size1,size2);
    UnlimitedInt* arr1=new UnlimitedInt();
    arr1->capacity=max_size;
    if (size1>=size2){
        arr1=div(i1,i2);
        result=sub(i1,mul(arr1,i2));
        removeLeadingZeroes(result->get_array(),max_size);
        return result;
    }
    else{
        arr1=div(i2,i1);
        result=sub(i2,mul(arr1,i1));
        removeLeadingZeroes(result->get_array(),max_size);
        return result;
    }
    for (int i=0; i<max_size; i++){
        result[i]=0;
    }
    result->size = removeLeadingZeroes(result->get_array(),max_size);
    return result;
};

// Conversion Functions 
string UnlimitedInt::to_string(){
    string result="";
    UnlimitedInt num;

    for (int i=0; i<num.get_size(); i++){
        result+=char(num.get_array()[i]);
    }
    return result;
};

int main(){
    UnlimitedInt *num1 = new UnlimitedInt(99);
    UnlimitedInt *num2 = new UnlimitedInt(11);
    UnlimitedInt *res = new UnlimitedInt();
    res = res->div(num1,num2);
    cout<<res->get_array()[0]<<res->get_array()[1]<<endl;
    cout<<res->get_sign()<<endl;
}